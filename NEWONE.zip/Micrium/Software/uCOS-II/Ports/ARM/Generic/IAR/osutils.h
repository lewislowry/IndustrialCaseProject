#ifndef __OSUTILS_H
#define __OSUTILS_H

void osStartTick(void);

#endif