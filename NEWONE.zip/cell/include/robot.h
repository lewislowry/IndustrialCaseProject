#ifndef __ROBOT_H
#define __ROBOT_H

#include <stdint.h>

typedef enum robotJoint {ROBOT_HAND=1, ROBOT_WRIST=2, ROBOT_ELBOW=3, ROBOT_WAIST=4} robotJoint_t;
typedef enum robotJointStep_t {ROBOT_JOINT_POS_INC, ROBOT_JOINT_POS_DEC} robotJointStep_t;
typedef enum robotNewState_t {HAND_OPEN = 47250, ELBOW_PICKUP = 45000, WRIST_PICKUP = 88750, WAIST_PICKUP = 75750, HAND_CLOSE = 10000} robotNewState_t;

void robotInit(void);
void robotJointSetState(robotJoint_t, robotJointStep_t);
void setPositions(robotJoint_t, robotNewState_t);
uint32_t robotJointGetState(robotJoint_t);
uint32_t robotJointGetMinPos(robotJoint_t);
uint32_t robotJointGetMaxPos(robotJoint_t);
uint32_t robotJointGetStepValue(void);

#endif
