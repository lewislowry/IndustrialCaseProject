#ifndef __POTENTIOMETER_H
#define __POTENTIOMETER_H

#include <stdint.h>

void potentiometerInit(void);
uint32_t potentiometerRead(void);

#endif 