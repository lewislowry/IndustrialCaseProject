#ifndef __DELAY
#define __DELAY

#include <stdint.h>

void dly100us(uint32_t);

#endif 